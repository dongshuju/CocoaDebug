//
//  Example
//  man
//
//  Created by man on 11/11/2018.
//  Copyright © 2018 man. All rights reserved.
//

#import <UIKit/UIKit.h>

@class _MLBFileInfo;

@interface _MLBFilePreviewController : UIViewController

@property (nonatomic, strong) _MLBFileInfo *fileInfo;

@end
